var dir_45d74bc441eb221bffbee64aa4054eb5 =
[
    [ ".NETCoreApp,Version=v9.0.AssemblyAttributes.cs", "_release_2net9_80_2_8_n_e_t_core_app_00_version_0av9_80_8_assembly_attributes_8cs.html", null ],
    [ "C# - PROJECT.AssemblyInfo.cs", "_release_2net9_80_2_c_0g_01-_01_p_r_o_j_e_c_t_8_assembly_info_8cs.html", null ],
    [ "C# - PROJECT.GlobalUsings.g.cs", "_release_2net9_80_2_c_0g_01-_01_p_r_o_j_e_c_t_8_global_usings_8g_8cs.html", null ]
];