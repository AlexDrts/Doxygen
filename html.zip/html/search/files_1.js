var searchData=
[
  ['c_23_20_2d_20project_2eassemblyinfo_2ecs_0',['C# - PROJECT.AssemblyInfo.cs',['../_debug_2net9_80_2_c_0g_01-_01_p_r_o_j_e_c_t_8_assembly_info_8cs.html',1,'(Global Namespace)'],['../_release_2net9_80_2_c_0g_01-_01_p_r_o_j_e_c_t_8_assembly_info_8cs.html',1,'(Global Namespace)']]],
  ['c_23_20_2d_20project_2eglobalusings_2eg_2ecs_1',['C# - PROJECT.GlobalUsings.g.cs',['../_debug_2net9_80_2_c_0g_01-_01_p_r_o_j_e_c_t_8_global_usings_8g_8cs.html',1,'(Global Namespace)'],['../_release_2net9_80_2_c_0g_01-_01_p_r_o_j_e_c_t_8_global_usings_8g_8cs.html',1,'(Global Namespace)']]]
];
